//
//  ChatDataModel.m
//  TextMessager
//
//  Created by Nebula_MAC on 2015. 12. 13..
//  Copyright © 2015년 Nebula_MAC. All rights reserved.
//

#import "ChatDataModel.h"

@implementation ChatDataModel

@synthesize  pTime;
@synthesize  pContext;
@synthesize  pUserImage;
@synthesize  LeftYN;

@end
