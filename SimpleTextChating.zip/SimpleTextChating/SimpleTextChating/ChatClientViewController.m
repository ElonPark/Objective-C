//
//  ChatClientViewController.m
//  SimpleTextChating
//
//  Created by Broad_102-12 on 2015. 12. 14..
//  Copyright (c) 2015년 201116041_ParkSungWoon. All rights reserved.
//

#import "ChatClientViewController.h"
#import "ViewController.h"
@interface ChatClientViewController ()

@end

@implementation ChatClientViewController

@synthesize inputStream, outputStream;
@synthesize inputMessageField;
@synthesize messages,tView;


- (void)viewDidLoad {
    [self initNetworkCommunication];
    
    
    messages = [[NSMutableArray alloc] init];
    
    [tView setText:@"\n"];
    
    NSString *response  = [NSString stringWithFormat:@"Hello\n" ];
    NSData *data = [[NSData alloc] initWithData:[response dataUsingEncoding:NSASCIIStringEncoding]];
    [outputStream write:[data bytes] maxLength:[data length]];

   
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}



- (void) initNetworkCommunication {
    
    CFReadStreamRef readStream;
    CFWriteStreamRef writeStream;
    CFStreamCreatePairWithSocketToHost(NULL, (CFStringRef)@"localhost", 1215, &readStream, &writeStream);
    
    inputStream = (NSInputStream *)CFBridgingRelease(readStream);
    outputStream = (NSOutputStream *)CFBridgingRelease(writeStream);
    [inputStream setDelegate:self];
    [outputStream setDelegate:self];
    [inputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [outputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [inputStream open];
    [outputStream open];
    
}


- (IBAction) sendMessage {
    
    NSString *response  = [NSString stringWithFormat:@"Apple: %@\n", inputMessageField.text];
    NSData *data = [[NSData alloc] initWithData:[response dataUsingEncoding:NSASCIIStringEncoding]];
    [outputStream write:[data bytes] maxLength:[data length]];
    inputMessageField.text = @"";
    
    [self.messages addObject:response];
    [tView setText:[NSString stringWithFormat:@"%@\n%@",[tView text], response]];
    [tView scrollRangeToVisible:NSMakeRange([[tView text]length], 0)];
  

    
    
}

- (void)stream:(NSStream *)theStream handleEvent:(NSStreamEvent)streamEvent {
    
    NSLog(@"stream event %i", streamEvent);
    
    switch (streamEvent) {
            
        case NSStreamEventOpenCompleted:
            NSLog(@"Stream opened");
            break;
        case NSStreamEventHasBytesAvailable:
            
            if (theStream == inputStream) {
                
                uint8_t buffer[1024];
                int len;
                
                while ([inputStream hasBytesAvailable]) {
                    len = [inputStream read:buffer maxLength:sizeof(buffer)];
                    if (len > 0) {
                        
                        NSString *output = [[NSString alloc] initWithBytes:buffer length:len encoding:NSASCIIStringEncoding];
                        
                        if (nil != output) {
                            
                            NSLog(@"server said: %@", output);
                            [self messageReceived:output];
                            
                        }
                    }
                }
            }
            break;
            
            
        case NSStreamEventErrorOccurred:
            
            NSLog(@"Can not connect to the host!");
            break;
            
        case NSStreamEventEndEncountered:
            
            [theStream close];
            [theStream removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
           
            theStream = nil;
            
            break;
        default:
            NSLog(@"Unknown event");
    }
    
}

- (void) messageReceived:(NSString *)message {
    
    [self.messages addObject:message];
    /*
    UITextView *textView = self.tView;
    NSRange selectedRange = textView.selectedRange;
    UITextRange *textRange = [textView textRangeFromPosition:textView.selectedTextRange.start toPosition:textView.selectedTextRange.start];
    
    [textView replaceRange:textRange withText:message];
    [textView setSelectedRange:NSMakeRange(selectedRange.location + 1, 0)];
    */
    [tView setText:[NSString stringWithFormat:@"%@\n%@",[tView text], message]];
    [tView scrollRangeToVisible:NSMakeRange([[tView text]length], 0)];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
