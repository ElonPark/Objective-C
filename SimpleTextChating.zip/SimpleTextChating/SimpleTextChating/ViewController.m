//
//  ViewController.m
//  SimpleTextChating
//
//  Created by Broad_102-12 on 2015. 12. 14..
//  Copyright (c) 2015년 201116041_ParkSungWoon. All rights reserved.
//

#import "ViewController.h"



@implementation ViewController


@synthesize inputNameField;


- (void)viewDidLoad {
    
   
    [super viewDidLoad];
    
    inputNameField.text = @"Apple";
   
    }




- (IBAction) joinChat {
    UserName = inputNameField.text;
      
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
