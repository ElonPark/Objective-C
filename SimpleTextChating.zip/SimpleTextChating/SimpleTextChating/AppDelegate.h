//
//  AppDelegate.h
//  SimpleTextChating
//
//  Created by Broad_102-12 on 2015. 12. 14..
//  Copyright (c) 2015년 201116041_ParkSungWoon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
}
@property (strong, nonatomic) UIWindow *window;


@end

