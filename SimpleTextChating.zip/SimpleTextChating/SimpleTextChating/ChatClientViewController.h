//
//  ChatClientViewController.h
//  SimpleTextChating
//
//  Created by Broad_102-12 on 2015. 12. 14..
//  Copyright (c) 2015년 201116041_ParkSungWoon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
@interface ChatClientViewController : UIViewController <NSStreamDelegate, UITableViewDelegate, UITableViewDataSource> {
    
  
    NSInputStream	*inputStream;
    NSOutputStream	*outputStream;
    UITextField		*inputMessageField;
    UITextView		*tView;
    NSMutableArray	*messages;
    
}


//@property (weak, nonatomic) NSString* UserName;
@property (nonatomic, retain) NSInputStream *inputStream;
@property (nonatomic, retain) NSOutputStream *outputStream;
@property (nonatomic, retain) IBOutlet UITextField	*inputMessageField;
@property (nonatomic, retain) IBOutlet UITextView	*tView;
@property (nonatomic, retain) NSMutableArray *messages;

- (void) initNetworkCommunication;
- (IBAction) sendMessage;
- (void) messageReceived:(NSString *)message;



@end
