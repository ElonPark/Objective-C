//
//  ViewController.h
//  SimpleTextChating
//
//  Created by Broad_102-12 on 2015. 12. 14..
//  Copyright (c) 2015년 201116041_ParkSungWoon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    
        UITextField		*inputNameField;
        NSString *UserName;
    
}



@property (nonatomic, retain) IBOutlet UITextField	*inputNameField;

- (IBAction) joinChat;




@end

